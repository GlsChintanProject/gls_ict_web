<?php
$sql = mysqli_connect("mysql.1freehosting.com","u266066249_root","optimus_Prime1","u266066249_glsdb");
$db = mysql_connect("mysql.1freehosting.com","u266066249_root","optimus_Prime1");
mysql_select_db("u266066249_glsdb",$db);
?>